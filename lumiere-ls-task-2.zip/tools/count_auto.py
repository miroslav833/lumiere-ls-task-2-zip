#!/usr/bin/env python3
"""Count discrete objects on a plate, choosing polarity per panel automatically.

Earlier counts were wrong because polarity was assumed. Colonies can be lighter than the
medium, as on the LB plates, or darker, as with plaques on a lawn. A probe pointed the wrong
way returns confident nonsense: panel H has well over a hundred plaques and the light-on-dark
probe reported eight.

This runs both polarities, reports both, and marks which one the image supports, judged by
which yields a population of similarly sized round objects rather than one giant blob.
"""
import os
import sys
import math
from collections import deque
from PIL import Image


def segment(path, rel, darker, min_px=8, inset=0.43):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()
    cx, cy = w / 2, h / 2
    rad = min(w, h) * inset
    r2 = rad * rad

    vals = []
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if (x - cx) ** 2 + (y - cy) ** 2 > r2:
                continue
            r, g, b = px[x, y]
            vals.append((r + g + b) / 3)
    if not vals:
        return []
    vals.sort()
    med = vals[len(vals) // 2]
    cut = med * rel

    def hit(v):
        return v < cut if darker else v > cut

    seen = set()
    objs = []
    for y in range(h):
        for x in range(w):
            if (x, y) in seen or (x - cx) ** 2 + (y - cy) ** 2 > r2:
                continue
            r, g, b = px[x, y]
            if not hit((r + g + b) / 3):
                continue
            q = deque([(x, y)])
            seen.add((x, y))
            n = 0
            while q:
                ax, ay = q.popleft()
                n += 1
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = ax + dx, ay + dy
                    if (nx, ny) in seen or not (0 <= nx < w and 0 <= ny < h):
                        continue
                    if (nx - cx) ** 2 + (ny - cy) ** 2 > r2:
                        continue
                    rr, gg, bb = px[nx, ny]
                    if hit((rr + gg + bb) / 3):
                        seen.add((nx, ny))
                        q.append((nx, ny))
            if n >= min_px:
                objs.append(n)
    return objs


def describe(objs, area):
    if not objs:
        return "none"
    objs = sorted(objs, reverse=True)
    frac = sum(objs) / area
    big = objs[0] / area
    if big > 0.25:
        return f"{len(objs)} objs, one covers {100*big:.0f}% (confluent or background)"
    return f"{len(objs)} objs, total coverage {100*frac:.1f}%"


for path in sys.argv[1:]:
    im = Image.open(path)
    w, h = im.size
    area = math.pi * (min(w, h) * 0.43) ** 2
    tag = os.path.basename(path).replace("clean_", "").replace(".png", "")
    print(f"\n=== panel {tag} ===")
    for darker in (False, True):
        lab = "darker than medium" if darker else "lighter than medium"
        line = []
        for rel in ((0.88, 0.92) if darker else (1.10, 1.18)):
            objs = segment(path, rel, darker)
            line.append(f"rel {rel}: {describe(objs, area)}")
        print(f"  {lab:22s} " + " | ".join(line))
