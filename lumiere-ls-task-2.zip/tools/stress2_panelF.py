#!/usr/bin/env python3
"""Second, independently built count for panel F, with no local background grid.

The first stress test used a blocky local background estimate, and at loose settings that grid
carved the largest cell into pieces. The carving is an artefact of the grid, not of the image:
a green channel profile straight through that cell rises and falls once, with no dimmer seam.
This version drops the grid and thresholds globally, which is what a reader does by eye.

A cell is a connected body whose green value is above the threshold and whose green minus blue
is above 60, so the white scale bar is not a cell. Bodies meeting the frame are excluded.
"""
import sys
from collections import deque
from PIL import Image

UMPP = 10.0 / 222


def load(path):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()
    g = [[px[x, y][1] for x in range(w)] for y in range(h)]
    b = [[px[x, y][2] for x in range(w)] for y in range(h)]
    return w, h, g, b


def count(w, h, g, b, T, min_px, verbose=False):
    def on(x, y):
        return g[y][x] > T and g[y][x] - b[y][x] > 60

    seen = set(); keep = []; dropped = 0
    for y in range(h):
        for x in range(w):
            if (x, y) in seen or not on(x, y): continue
            q = deque([(x, y)]); seen.add((x, y)); cells = []
            while q:
                ax, ay = q.popleft(); cells.append((ax, ay))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = ax + dx, ay + dy
                    if (nx, ny) in seen or not (0 <= nx < w and 0 <= ny < h): continue
                    if on(nx, ny): seen.add((nx, ny)); q.append((nx, ny))
            if len(cells) < min_px: continue
            xs = [c[0] for c in cells]; ys = [c[1] for c in cells]
            if min(xs) <= 1 or min(ys) <= 1 or max(xs) >= w - 2 or max(ys) >= h - 2:
                dropped += 1; continue
            keep.append((len(cells), sum(xs) / len(xs) / w * 100, sum(ys) / len(ys) / h * 100,
                         (max(xs) - min(xs) + 1) * UMPP, (max(ys) - min(ys) + 1) * UMPP))
    if verbose:
        for n, cx, cy, bw, bh in sorted(keep, key=lambda r: r[2]):
            print(f"   {n:6d} px  centre ({cx:5.1f}%, {cy:5.1f}%)  bbox {bw:4.2f} x {bh:4.2f} um")
    return len(keep), dropped


if __name__ == "__main__":
    path = sys.argv[1]
    w, h, g, b = load(path)
    print(f"{path}  {w} x {h} px = {w*UMPP:.3f} x {h*UMPP:.3f} um, "
          f"area {w*UMPP*h*UMPP:.1f} um2")
    print("\nobjects at T=150, min 200 px:")
    count(w, h, g, b, 150, 200, verbose=True)
    print("\nthreshold T across minimum sizes:")
    res = []
    for T in (110, 120, 130, 140, 150, 160, 170, 180, 190, 200):
        row = []
        for min_px in (50, 100, 200, 400, 800):
            k, d = count(w, h, g, b, T, min_px)
            row.append(k); res.append(k)
        print(f"  T {T:3d}: {row}")
    print(f"\n  range {min(res)} to {max(res)}, spread {max(res)-min(res)}, n={len(res)}")
