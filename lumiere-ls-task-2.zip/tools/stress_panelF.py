#!/usr/bin/env python3
"""Stress test the interior cell count on the cropped panel F field.

A labelled cell is a connected body which is bright in the green channel, brighter than its own
local background, and yellow rather than white. The yellow test is what keeps the scale bar out,
and the prompt states separately that the scale bar is not a cell. Objects which meet the frame
are excluded, as the prompt states.

54 settings: six brightness bumps, three local background margins, three minimum sizes.
"""
import sys
from collections import deque
from PIL import Image

UMPP = 10.0 / 222


def otsu(hist, total):
    sa = sum(i * c for i, c in enumerate(hist)); sb = 0.0; wb = 0; bt = 0; bv = -1.0
    for t in range(256):
        wb += hist[t]
        if wb == 0: continue
        wf = total - wb
        if wf == 0: break
        sb += t * hist[t]
        mb = sb / wb; mf = (sa - sb) / wf
        v = wb * wf * (mb - mf) ** 2
        if v > bv: bv, bt = v, t
    return bt


def load(path):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()
    g = [[px[x, y][1] for x in range(w)] for y in range(h)]
    b = [[px[x, y][2] for x in range(w)] for y in range(h)]
    return w, h, g, b


def count(w, h, g, b, bump, margin, min_px, verbose=False):
    hist = [0] * 256
    for row in g:
        for v in row: hist[v] += 1
    T = min(255, otsu(hist, w * h) + bump)
    STEP = 48
    bg = {}
    for gy in range(0, h, STEP):
        for gx in range(0, w, STEP):
            vals = [g[y][x] for y in range(gy, min(gy + STEP, h), 4)
                    for x in range(gx, min(gx + STEP, w), 4)]
            bg[(gx // STEP, gy // STEP)] = sum(vals) / len(vals) if vals else 0

    def on(x, y):
        return (g[y][x] > T and g[y][x] > bg[(x // STEP, y // STEP)] + margin
                and g[y][x] - b[y][x] > 60)          # yellow, not white

    seen = set(); keep = []; dropped = []
    for y in range(h):
        for x in range(w):
            if (x, y) in seen or not on(x, y): continue
            q = deque([(x, y)]); seen.add((x, y)); cells = []
            while q:
                ax, ay = q.popleft(); cells.append((ax, ay))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = ax + dx, ay + dy
                    if (nx, ny) in seen or not (0 <= nx < w and 0 <= ny < h): continue
                    if on(nx, ny): seen.add((nx, ny)); q.append((nx, ny))
            if len(cells) < min_px: continue
            xs = [c[0] for c in cells]; ys = [c[1] for c in cells]
            edge = min(xs) <= 1 or min(ys) <= 1 or max(xs) >= w - 2 or max(ys) >= h - 2
            rec = (len(cells), sum(xs) / len(xs), sum(ys) / len(ys),
                   (max(xs) - min(xs) + 1) * UMPP, (max(ys) - min(ys) + 1) * UMPP)
            (dropped if edge else keep).append(rec)
    if verbose:
        for n, cx, cy, bw, bh in sorted(keep, key=lambda r: r[2]):
            print(f"   {n:6d} px  centre ({cx/w*100:5.1f}%, {cy/h*100:5.1f}%)  "
                  f"bbox {bw:4.2f} x {bh:4.2f} um")
        for n, cx, cy, bw, bh in dropped:
            print(f"   dropped at frame: {n} px at ({cx/w*100:.1f}%, {cy/h*100:.1f}%)")
    return len(keep), len(dropped)


if __name__ == "__main__":
    path = sys.argv[1]
    w, h, g, b = load(path)
    print(f"{path}  {w} x {h} px = {w*UMPP:.3f} x {h*UMPP:.3f} um, "
          f"area {w*UMPP*h*UMPP:.1f} um2")
    print("\nbaseline objects:")
    count(w, h, g, b, 0, 18, 40, verbose=True)
    print("\n54 settings:")
    res = []
    for bump in (-10, -5, 0, 5, 10, 20):
        row = []
        for margin in (10, 18, 26):
            for min_px in (25, 40, 80):
                k, d = count(w, h, g, b, bump, margin, min_px)
                row.append(k); res.append(k)
        print(f"  bump {bump:+3d}: {row}")
    print(f"\n  interior count range {min(res)} to {max(res)}, spread {max(res)-min(res)}, "
          f"n={len(res)}")
