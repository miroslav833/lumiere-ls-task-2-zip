#!/usr/bin/env python3
"""Second, independently built count of fluorescent cells on a dark field.

The first method thresholds on mean brightness relative to the field median. This one differs
in every choice that matters, so agreement means something:

  - works on the GREEN channel alone, since the signal is a green fluorophore
  - threshold set from the channel histogram by Otsu, not from a median multiplier
  - requires an object to be locally brighter than its own surroundings, which rejects the
    diffuse haze that a global threshold picks up
  - splits touching objects by a distance criterion rather than accepting one blob

Reports the count and the per object diameter in pixels so a size criterion can be checked.
"""
import sys
import math
from collections import deque
from PIL import Image


def otsu(hist, total):
    sum_all = sum(i * h for i, h in enumerate(hist))
    sum_b = 0.0
    w_b = 0
    best_t, best_var = 0, -1.0
    for t in range(256):
        w_b += hist[t]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break
        sum_b += t * hist[t]
        m_b = sum_b / w_b
        m_f = (sum_all - sum_b) / w_f
        var = w_b * w_f * (m_b - m_f) ** 2
        if var > best_var:
            best_var, best_t = var, t
    return best_t


def count(path, bump=0, min_px=15, local_margin=18):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()

    green = [[px[x, y][1] for x in range(w)] for y in range(h)]
    hist = [0] * 256
    for row in green:
        for v in row:
            hist[v] += 1
    t = min(255, otsu(hist, w * h) + bump)

    # local background: mean green over a coarse grid cell
    STEP = 48
    bg = {}
    for gy in range(0, h, STEP):
        for gx in range(0, w, STEP):
            vals = [green[y][x]
                    for y in range(gy, min(gy + STEP, h), 4)
                    for x in range(gx, min(gx + STEP, w), 4)]
            bg[(gx // STEP, gy // STEP)] = sum(vals) / len(vals) if vals else 0

    def is_cell(x, y):
        v = green[y][x]
        if v <= t:
            return False
        return v > bg[(x // STEP, y // STEP)] + local_margin

    seen = set()
    diams = []
    for y in range(h):
        for x in range(w):
            if (x, y) in seen or not is_cell(x, y):
                continue
            q = deque([(x, y)])
            seen.add((x, y))
            n = 0
            while q:
                ax, ay = q.popleft()
                n += 1
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = ax + dx, ay + dy
                    if (nx, ny) in seen or not (0 <= nx < w and 0 <= ny < h):
                        continue
                    if is_cell(nx, ny):
                        seen.add((nx, ny))
                        q.append((nx, ny))
            if n >= min_px:
                diams.append(2 * math.sqrt(n / math.pi))
    return t, sorted(diams, reverse=True)


for path in sys.argv[1:]:
    print(f"\n=== {path.split('/')[-1]} ===")
    print(f"{'bump':>5} {'thresh':>7} {'cells':>6}   diameters px")
    counts = []
    for bump in (-10, 0, 10, 20, 30):
        t, d = count(path, bump=bump)
        counts.append(len(d))
        shown = " ".join(f"{x:.0f}" for x in d[:14])
        print(f"{bump:5d} {t:7d} {len(d):6d}   {shown}")
    print(f"  range {min(counts)} to {max(counts)}, spread {max(counts)-min(counts)}")
