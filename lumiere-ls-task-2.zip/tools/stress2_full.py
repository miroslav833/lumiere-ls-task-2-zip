#!/usr/bin/env python3
"""Second counter run on the uncropped field (1980 x 1452), the version actually submitted.

Confirms the white margin on the right and bottom does not get counted as a cell: it is
rejected by the green-minus-blue test the same as the white scale bar is.
"""
import sys
from collections import deque
from PIL import Image

UMPP = 10.0 / 222


def load(path):
    im = Image.open(path).convert("RGB")
    w, h = im.size
    px = im.load()
    g = [[px[x, y][1] for x in range(w)] for y in range(h)]
    b = [[px[x, y][2] for x in range(w)] for y in range(h)]
    return w, h, g, b


def count(w, h, g, b, T, min_px):
    def on(x, y):
        return g[y][x] > T and g[y][x] - b[y][x] > 60

    seen = set(); keep = 0; dropped = 0
    for y in range(h):
        for x in range(w):
            if (x, y) in seen or not on(x, y): continue
            q = deque([(x, y)]); seen.add((x, y)); cells = []
            while q:
                ax, ay = q.popleft(); cells.append((ax, ay))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = ax + dx, ay + dy
                    if (nx, ny) in seen or not (0 <= nx < w and 0 <= ny < h): continue
                    if on(nx, ny): seen.add((nx, ny)); q.append((nx, ny))
            if len(cells) < min_px: continue
            xs = [c[0] for c in cells]; ys = [c[1] for c in cells]
            if min(xs) <= 1 or min(ys) <= 1 or max(xs) >= w - 2 or max(ys) >= h - 2:
                dropped += 1; continue
            keep += 1
    return keep, dropped


if __name__ == "__main__":
    path = sys.argv[1]
    w, h, g, b = load(path)
    print(f"{path}  {w} x {h} px")
    res = []
    for T in (110, 120, 130, 140, 150, 160, 170, 180, 190, 200):
        row = []
        for min_px in (50, 100, 200, 400, 800):
            k, d = count(w, h, g, b, T, min_px)
            row.append(k); res.append(k)
        print(f"  T {T:3d}: {row}")
    print(f"\n  range {min(res)} to {max(res)}, spread {max(res)-min(res)}, n={len(res)}")
