# Life-Science task 2: yeast cell density from a hybridised kefir grain section

Status: NOT YET RUN in this form. An earlier form of this task ran and both models failed, but
that run is void because the ground truth was wrong. See the corrections below.

Domain Life-Science, assay type Agri-Food and Environmental Micro, subdomain Microbiology. The
image is one epifluorescence field of a hybridised thin section of a Tibetan kefir grain. The
question asks for the density of labelled cells per cubic millimetre of grain tissue. The
answer is 2.1e5 per mm3.

| Field | Value |
|---|---|
| Subdomain | Microbiology |
| Where did the image(s) come from | External publication |
| Source URL or DOI | 10.1371/journal.pone.0101387 |
| License | CC BY 4.0 |
| Reference material | Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity, and Shift. PLoS ONE. 2014;9(7):e101387 |
| Publication venue | PLOS ONE |
| Image | image.png, 1956 x 1440, one field, md5 fdc806a86578ab973416de7fc3c7f787 |
| Answer format | Decimal, a 2 significant figure number |

## Step 6. GTFA

2.1e5 per cubic millimetre, entered as 210000

## Checkboxes

| Statement | Answer |
|---|---|
| I've double checked my spelling and grammar. | True |
| My prompt is not duplicative, plagiarized, or LLM-generated. | Box 2 is Miroslav's, leave it |
| My prompt is self-contained and fully solvable without external resources. | True |
| The prompt can only be solved with the information in the image. | True |

---

## Correction 1: the measurement the earlier version asked for

The earlier prompt said to measure each object "across its widest point". The ground truth was
built from the equivalent circle diameter, which is the diameter of a circle with the same area
as the object. Those are two different quantities, and for anything which is not round the
widest point is the larger of the two. The task therefore specified one measurement and was
verified against another.

Measuring the widest point as the prompt asked gave 9 to 11 qualifying objects rather than 3,
and the count moved with every segmentation setting. The two methods used to verify the earlier
number agreed with each other only because both computed the same wrong quantity.

The run in which both models failed is therefore void. The models answered 7.5e5 and 4.7e5 from
counts of 18 and 16, so the difficulty check did not test what it was supposed to test.

The size threshold is gone. Every labelled cell counts now, so the unstable part of that design
is removed.

## Correction 2: the white margin on the image

The panel carried over a white margin from the published figure, 24 columns on the right and 12
rows at the bottom of a 1980 x 1452 crop. That margin is a bright connected body which is not a
cell and which the prompt did not exclude, and worse, it moved the field area by 2 percent. At a
section thickness of 3.0 um the answer was 3.4e5 with the margin counted as field and 3.5e5
without it, so the first two significant figures turned on a detail nobody would notice.

The margin is cropped off. The field is now 1956 x 1440 pixels and every pixel of it is
micrograph.

## Correction 3: the section thickness

With the margin gone the answer at 3.0 um was 349949, which sits 1.4 percent under the 345000
boundary between 3.4e5 and 3.5e5. A two significant figure answer that close to a rounding
boundary is not safe, because a small error in reading the scale bar flips the reported digits.

The stated thickness is now 5.0 um, which is an ordinary cryosection thickness and which puts
the answer at 209969. That is 210000 to two significant figures, and the bin runs from 205000 to
215000, so the answer survives a 2.3 percent error in the field area.

## Ground truth

The scale bar is 222 px for 10.0 um, so one pixel is 0.045045 um. The field is 1956 by 1440 px,
which is 88.108 by 64.865 um, an area of 5715.1 um2. Over a section thickness of 5.0 um the
sampled tissue is 28575.6 um3, which is 2.857560e-5 mm3.

Six cells in that volume is 209969 per mm3, which to two significant figures is **2.1e5 per
cubic millimetre**.

### The six cells

Centres as a fraction of width and of height, with bounding boxes in pixels:

| # | centre | size | note |
|---|---|---|---|
| 1 | 0.615, 0.217 | 127 x 79 | largest body in the field |
| 2 | 0.975, 0.208 | 63 x 48 | stops 17 px short of the right edge, so it is whole |
| 3 | 0.204, 0.371 | 94 x 64 | |
| 4 | 0.533, 0.471 | 58 x 63 | closest pair with 5, separated by a dark gap |
| 5 | 0.505, 0.528 | 68 x 58 | |
| 6 | 0.317, 0.816 | 65 x 52 | |

No cell meets the frame, so the edge rule in the prompt excludes nothing. The rule is still
stated, because without it a reader cannot tell whether cell 2 counts.

### Verification

Two counters were built, and they disagree in a way worth recording.

`tools/stress_panelF.py` thresholds the green channel by Otsu and also requires each object to
beat a local background estimated on a 48 pixel grid. Across 54 settings it returns 6 to 8. The
extra objects are always fragments of cell 1, which is the largest cell, and they appear only
when the grid margin is loose. That is an artefact of the grid: a green channel profile cut
straight through cell 1 rises once and falls once, with no dimmer seam, so cell 1 is one cell
and the grid is carving it.

`tools/stress2_panelF.py` drops the grid and thresholds globally, which is what a reader does by
eye. Across 50 settings, ten thresholds from 110 to 200 crossed with five minimum sizes from 50
to 800 pixels, it returns 6 every time. Spread 0.

Both counters require green minus blue above 60, which keeps the white scale bar out, and the
prompt states separately that the scale bar is not a cell.

The global count of 6 is the ground truth. It matches what the field shows at full size.

## Sensitivity

| count reached | answer | distance |
|---|---|---|
| 5 | 1.7e5 | 17 percent low |
| **6** | **2.1e5** | correct |
| 7 | 2.4e5 | 17 percent high |
| 8 | 2.8e5 | 33 percent high |

Every miscounted cell moves the answer by about a sixth, well outside the two percent band.

## Where the difficulty sits

Cell 2 sits 0.77 um from the right edge of the field, close enough that a reader who applies the
edge rule carelessly drops it and reaches 5. Cells 4 and 5 are 4.4 um apart centre to centre, with a gap of about 1.8 um between their edges, and
a reader who merges them also reaches 5. The faint orange patches in the background are
autofluorescence of the grain matrix rather than probe signal, and a reader who counts those
reaches a higher number. The field dimensions have to be recovered from the scale bar, and on
the earlier run one model put the field area at 8.00e3 um2 against a true 5.72e3 um2, so the
scale reading is itself a real source of error.

## Expected checker findings and the rebuttals

NON_FOUNDATIONAL_REFERENCE, which fires on every image task:

> The task is a multimodal task by design. The project rules require that the prompt can only
> be solved with the information in the image, and the image is attached. The checker is
> reading the prompt text without the attachment.

DOMAIN_KNOWLEDGE_FLOOR, if raised:

> The prompt states the preparation and the counting conventions, and nothing else. It does not
> say that a thin section samples a volume, that the volume is the area of the field times the
> thickness of the section, that the area has to be recovered from the scale bar, or that the
> dim background is autofluorescence rather than probe signal. Those steps are what turns a
> count into a cell density, and they are the standard way abundance is reported from a
> sectioned sample.

SUBTYPE_MISMATCH, which the Image Scope Checker has already cleared on this image class:

> The image is a hybridised thin section mounted on a slide and read by epifluorescence
> microscopy, which is a slide preparation and not a culture plate. The sample is a grain used
> to ferment milk, so the preparation and the sample are both within Agri-Food and
> Environmental Micro.

## Attribution

Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity,
and Shift. PLoS ONE. 2014;9(7):e101387. doi 10.1371/journal.pone.0101387. Licensed CC BY 4.0.
Figure 3 panel F, cropped to the field and upscaled.
