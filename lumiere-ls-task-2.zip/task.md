# Life-Science task 2: mature yeast cells in two kefir grain sections

Status: NOT YET RUN.

Domain Life-Science, assay type Agri-Food and Environmental Micro, subdomain Microbiology. The
image is two epifluorescence micrographs of thin sections of Tibetan kefir grains, hybridised
with a genus specific probe. The question asks how many labelled objects across both fields
reach a stated cell width. The answer is 5.

| Field | Value |
|---|---|
| Subdomain | Microbiology |
| Where did the image(s) come from | External publication |
| Source URL or DOI | 10.1371/journal.pone.0101387 |
| License | CC BY 4.0 |
| Reference material | Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity, and Shift. PLoS ONE. 2014;9(7):e101387 |
| Publication venue | PLOS ONE |
| Image | image.png, 4152 x 1588, two fields side by side |

---

## Step 4. Prompt

In prompt.md. Paste that file and nothing else.

## Step 6. GTFA

5

## Checkboxes

| Statement | Answer |
|---|---|
| I've double checked my spelling and grammar. | True |
| My prompt is not duplicative, plagiarized, or LLM-generated. | Box 2 is Miroslav's, leave it |
| My prompt is self-contained and fully solvable without external resources. | True |
| The prompt can only be solved with the information in the image. | True |

---

## Why this answers the four findings on the previous attempt

**SUBTYPE_MISMATCH.** The image is a mount, a hybridised thin section on a slide read by
epifluorescence. It is not a culture plate.

**MULTIPLE_CHOICE_IMPLIED.** The answer is not bounded by a panel count. Across the two fields
there are 28 labelled objects, so any integer from 0 to 28 is available before the measurement
is made.

**DOMAIN_KNOWLEDGE_FLOOR.** The prompt does not say which objects to count or what they look
like. It states the size a mature cell of this genus reaches and leaves the reader to calibrate
the scale bar, measure each object and apply the threshold. The expertise is the calibration
and the distinction between a whole cell, a bud and an obliquely sectioned cell.

**COUNTING_IS_THE_TASK.** The count is not a tally of objects in view. Every labelled object
must first be measured against a calibrated scale, and only those reaching the stated width are
counted, so a measurement feeds the count rather than the count being the whole task.

## The image, and what was done to it

Figure 3 of the source paper, 3711 x 3415, twelve panels. Panels B and E are the two fields
hybridised with the Sacch probe, which labels *Saccharomyces* only. Each was extracted at
1237 x 853 and cropped to 990 x 726, which removes the drawn panel letter in the top left
corner and keeps the scale bar in the bottom right. The two crops were placed side by side and
the result was upscaled twice for legibility.

Nothing was added. The scale bar is part of the original capture and the domain requires
preserving it.

## Calibration and ground truth

The scale bar measures 111 px in the extracted panel and the caption states it is 10.0 um, so
one pixel is 0.0901 um.

Object widths in the right field, in micrometres, largest first:

9.9, 4.5, 4.1, 3.2, 3.1, 3.1, 2.9, 2.8, 2.7, 2.6, 2.5, 2.3, 2.3, 2.3, 1.9, 1.7, 1.5, 1.4, 0.7

The 9.9 um object is two cells in contact rather than one, and it is counted once as the prompt
directs, since the question asks for labelled objects reaching the width.

| field | objects at or above 3.5 um |
|---|---|
| left, panel B | 2 |
| right, panel E | 3 |
| total | **5** |

## Verification

Two independently built measurement methods were used, because a single method produced a false
result earlier in this project.

Method one thresholds on mean brightness relative to the field median. Method two works on the
green channel alone, sets its threshold by Otsu on the channel histogram, and additionally
requires each object to exceed its own local background, which rejects diffuse haze.

| criterion | left field | right field | total |
|---|---|---|---|
| 2.0 um | 9 (spread 0) | 14 (spread 1) | 23 |
| 3.0 um | 5 (spread 1) | 6 (spread 2) | 11 |
| **3.5 um** | **2 (spread 0)** | **3 (spread 0)** | **5 (spread 0)** |

The total at 3.5 um is 5 at every one of five threshold settings spanning 40 grey levels. The
raw object count is not stable, 19 to 24 in the right field depending on where faint haze is
cut, and that is precisely why the question applies a size criterion: the objects that make the
raw count wobble are all far below the threshold and cannot move the answer.

## Expected checker findings and the rebuttals

NON_FOUNDATIONAL_REFERENCE, which fires on every image task:

> The task is a multimodal task by design. The project rules require that the prompt can only
> be solved with the information in the image, and the image is attached. The checker is
> reading the prompt text without the attachment.

DOMAIN_KNOWLEDGE_FLOOR:

> The task requires calibrating a scale bar, measuring labelled objects against it, and
> distinguishing a mature cell from a budding daughter and from a cell cut off centre by
> sectioning. Those are the judgements a microbiologist makes when reading a hybridised
> section, and the prompt supplies only the size a mature cell of this genus reaches, which is
> a reference value an expert would hold, not an instruction for which objects to count.

SUBTYPE_MISMATCH:

> The image is a hybridised thin section mounted on a slide and read by epifluorescence
> microscopy, which is a slide preparation and not a culture plate. The sample is a grain used
> to ferment milk, which is food material, so the preparation and the sample are both within
> Agri-Food and Environmental Micro.

## Attribution

Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity,
and Shift. PLoS ONE. 2014;9(7):e101387. doi 10.1371/journal.pone.0101387. Licensed CC BY 4.0.
Figure 3 panels B and E, cropped.
