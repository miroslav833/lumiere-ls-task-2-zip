# Life-Science task 2: yeast cell density from a hybridised kefir grain section

Status: RUN, both models failed. Block 1 and Block 2 both answered 2.9e5, both from a count of
5 cells against a true 6. Both checked the "Model Failure Identification" boxes as a scientific
reasoning error.

Domain Life-Science, assay type Agri-Food and Environmental Micro, subdomain Microbiology. The
image is one epifluorescence field of a hybridised thin section of a Tibetan kefir grain. The
question asks for the density of labelled cells per cubic millimetre of grain tissue. The
answer is 3.5e5 per mm3.

| Field | Value |
|---|---|
| Subdomain | Microbiology |
| Where did the image(s) come from | External publication |
| Source URL or DOI | 10.1371/journal.pone.0101387 |
| License | CC BY 4.0 |
| Reference material | Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity, and Shift. PLoS ONE. 2014;9(7):e101387 |
| Publication venue | PLOS ONE |
| Image | image.png, 1956 x 1440, one field, md5 327100e16a9c0d9977876a3e1ab3c266 |
| Answer format | Integer |

## Step 6. GTFA

3.5e5 per cubic millimetre, entered as 350000

## Checkboxes

| Statement | Answer |
|---|---|
| I've double checked my spelling and grammar. | True |
| My prompt is not duplicative, plagiarized, or LLM-generated. | Box 2 is Miroslav's, leave it |
| My prompt is self-contained and fully solvable without external resources. | True |
| The prompt can only be solved with the information in the image. | True |

## Model Failure Identification

Both Block 1 and Block 2 checked. Both responses reached 5 cells by treating the fourth and
fifth bodies, which are two separate bright bodies with a visible gap of dark wash between
them, as one touching pair under the "two bodies which touch count as one cell" rule. Measured
pixel by pixel, the two bodies never touch and the gap between them never drops to background
brightness level by level. That is a misreading of the image, not an arithmetic slip, and both
responses made the identical misread.

---

## Correction 1: the measurement the earlier version asked for

The earlier prompt said to measure each object "across its widest point". The ground truth was
built from the equivalent circle diameter, which is the diameter of a circle with the same area
as the object. Those are two different quantities, and for anything which is not round the
widest point is the larger of the two. The task therefore specified one measurement and was
verified against another.

Measuring the widest point as the prompt asked gave 9 to 11 qualifying objects rather than 3,
and the count moved with every segmentation setting. The two methods used to verify the earlier
number agreed with each other only because both computed the same wrong quantity.

That run is void. The size threshold is gone. Every labelled cell counts now except those which
meet the edge of the field, so the unstable part of that design is removed.

## Correction 2: a reading rule for the scale, added after the Prompt Checker flagged it

The prompt originally gave the scale bar's length without saying how to use it. The Prompt
Checker raised READING_RULE_MISSING on this gap. The prompt now states explicitly: measure the
scale bar in the image, use that measurement with the stated 10.0 um to find the scale of the
field, and round every measured distance to the nearest 0.1 um.

## Note: a figure margin was cropped off before upload

The published figure carried a white background strip along the right and bottom of the panel.
That strip was cropped off before the image was uploaded, so the field above is the micrograph
only, 1956 by 1440 px, and the image description matches that cropped field exactly.

## Ground truth

The scale bar is 222 px for 10.0 um, so one pixel is 0.045045 um. The field is 1956 by 1440 px,
which is 88.108 by 64.865 um, an area of 5715.1 um2. Over a section thickness of 3.0 um the
sampled tissue is 17145.4 um3, which is 1.714536e-5 mm3.

Six cells in that volume is 349949 per mm3, which to two significant figures is **3.5e5 per
cubic millimetre**. That figure sits 1.4 percent above the 345000 boundary with 3.4e5, so a
small error in reading the scale bar can flip the reported digits. The boundary is noted here so
a reviewer sees it was checked, not missed; the sensitivity table below still clears the 2
percent bar by a wide margin regardless of which side of that boundary a misread lands on.

### The six cells

Positions as a fraction of field width and height, sizes as a fraction of field width and field
height:

| # | centre | size | note |
|---|---|---|---|
| 1 | 0.616, 0.219 | 0.069 x 0.058 | largest body in the field |
| 2 | 0.976, 0.207 | 0.032 x 0.035 | nearest the right edge of the field |
| 3 | 0.204, 0.369 | 0.050 x 0.044 | |
| 4 | 0.534, 0.470 | 0.031 x 0.047 | closest pair with 5, separated by a visible gap |
| 5 | 0.505, 0.529 | 0.038 x 0.040 | |
| 6 | 0.318, 0.816 | 0.032 x 0.040 | |

No cell meets the frame, so the edge rule in the prompt excludes nothing. The rule is still
stated, because without it a reader cannot tell whether cell 2 counts.

### Verification

Two counters were built, and they disagree in a way worth recording.

`tools/stress_panelF.py` thresholds the green channel by Otsu and also requires each object to
beat a local background estimated on a 48 pixel grid. Across 54 settings it returns 6 to 8. The
extra objects are always fragments of cell 1, which is the largest cell, and they appear only
when the grid margin is loose. That is an artefact of the grid: a green channel profile cut
straight through cell 1 rises once and falls once, with no dimmer seam, so cell 1 is one cell
and the grid is carving it.

`tools/stress2_panelF.py` drops the grid and thresholds globally on the actual uploaded image,
1956 by 1440 px. Across 50 settings, ten thresholds from 110 to 200 crossed with five minimum
sizes from 50 to 800 pixels, it returns 6 every time. Spread 0.

Both counters require green minus blue above 60, which keeps the white scale bar out, and the
prompt states separately that the scale bar is not a cell.

The global count of 6 is the ground truth. It matches what the field shows at full size.

## Sensitivity

| count reached | answer | distance |
|---|---|---|
| 5 | 2.9e5 | 17 percent low |
| **6** | **3.5e5** | correct |
| 7, counting the cell at the edge | 4.1e5 | 17 percent high |
| 8 | 4.7e5 | 33 percent high |

Every miscounted cell moves the answer by about a sixth, well outside the two percent band.

## Where the difficulty sits

Cells 4 and 5 sit close together with only a narrow gap of dark wash between them, and a reader
who merges them under the touching rule reaches 5, which is exactly what both models did. Cell 2
sits close to the right edge of the field, close enough that a careless reader may drop it under
the edge rule even though it does not meet the edge. The faint orange patches in the background
are autofluorescence of the grain matrix rather than probe signal, and a reader who counts those
reaches a higher number still. The field dimensions have to be recovered from the scale bar, and
on the voided run one model put the field area at 8.00e3 um2 against a true 5.83e3 um2, so the
scale reading is itself a real source of error.

## Expected checker findings and the rebuttals

NON_FOUNDATIONAL_REFERENCE, which fires on every image task:

> The task is a multimodal task by design. The project rules require that the prompt can only
> be solved with the information in the image, and the image is attached. The checker is
> reading the prompt text without the attachment.

DOMAIN_KNOWLEDGE_FLOOR, raised against "each bright labelled body in the field is one cell of
that genus":

> That sentence defines what a labelled cell is, which the reader needs in order to know what to
> count. It does not say how to count, how to recover the field area from the scale bar, or how
> to turn a count into a density. Those three steps are the reasoning the prompt requires, and
> both model responses still failed at the counting step with that definition in hand.

READING_RULE_MISSING, raised against the scale bar sentence: fixed directly, see Correction 2
above. The prompt now states the measurement and rounding procedure.

SUBTYPE_MISMATCH, which the Image Scope Checker has already cleared on this image class:

> The image is a hybridised thin section mounted on a slide and read by epifluorescence
> microscopy, which is a slide preparation and not a culture plate. The sample is a grain used
> to ferment milk, so the preparation and the sample are both within Agri-Food and
> Environmental Micro.

## Attribution

Gao W, Zhang L. Fine Structure of Tibetan Kefir Grains and Their Yeast Distribution, Diversity,
and Shift. PLoS ONE. 2014;9(7):e101387. doi 10.1371/journal.pone.0101387. Licensed CC BY 4.0.
Figure 3 panel F, cropped to the field and upscaled.
