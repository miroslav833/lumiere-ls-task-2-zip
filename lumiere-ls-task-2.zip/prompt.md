Image 1 shows two epifluorescence micrographs of thin sections cut from grains used to ferment a traditional cultured milk. Both sections were hybridised with the same fluorescent probe, which binds only to cells of one yeast genus, so every labelled object in either field belongs to that genus. The left field and the right field come from two separate grains. The white bar at the bottom right of each field is the scale bar for that field, and both fields were recorded at the same magnification.

The probe labels whole cells, so a labelled object whose greatest width reaches the size of a mature cell of this genus is one cell, while the smaller labelled objects are budding daughters and cells cut off centre by the sectioning. Take $3.5 \, \mu\text{m}$ as the smallest greatest width that a mature cell reaches. Find the total number of labelled objects across both fields whose greatest width is at least that size.

There are some things which stay fixed. Measure each object at its widest point, in the plane of the image. Use the scale bar in the field you are measuring. Count an object once, and count it in whichever field it appears. Use only what is visible in Image 1.

Report your final answer as a single integer.
