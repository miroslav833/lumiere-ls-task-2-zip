Image 1 shows an epifluorescence micrograph of a frozen "thin section" which was cut from a grain used to ferment a traditional cultured milk. The section was cut at a thickness of $5.0 \, \mu\text{m}$, then the section was hybridised with a fluorescent oligonucleotide probe. The probe binds to cells of a single yeast genus, and the probe binds to nothing else in the section, so each bright labelled body in the field is one cell of that genus. The white bar at the bottom right of the field is the "scale bar", and the scale bar is $10.0 \, \mu\text{m}$ long.

Find the number of cells of this genus per cubic millimetre of grain tissue.

There are some things which stay fixed. A labelled cell is one connected bright body whose boundary against the background can be placed to the nearest $0.1 \, \mu\text{m}$, and a dim patch whose boundary cannot be placed that closely is not a cell. Two bright bodies which touch count as one cell. A labelled cell which meets the edge of the field is not counted, because such a cell is cut by the edge and the whole of the cell is not in the field. The scale bar is not a labelled cell. The field is the whole of the area shown, and the sampled tissue is the part of the grain which lies inside the field and inside the thickness of the section.

Report your final answer as a 2 significant figure number.
